package sampleassertion;

import oracle.wsm.common.sdk.IContext;
import oracle.wsm.common.sdk.IMessageContext;
import oracle.wsm.common.sdk.IResult;
import oracle.wsm.common.sdk.Result;
import oracle.wsm.common.sdk.WSMException;
import oracle.wsm.policy.model.IAssertionBindings;
import oracle.wsm.policy.model.IConfig;
import oracle.wsm.policy.model.IPropertySet;
import oracle.wsm.policy.model.ISimpleOracleAssertion;
import oracle.wsm.policy.model.impl.SimpleAssertion;
import oracle.wsm.policyengine.impl.AssertionExecutor;

public class IpAssertionExecutor extends AssertionExecutor {
  public IpAssertionExecutor() {
  }


  //初期化

  public void init(oracle.wsm.policy.model.IAssertion assertion, oracle.wsm.policyengine.IExecutionContext econtext,
                   oracle.wsm.common.sdk.IContext context) {
    this.assertion = assertion;
    this.econtext = econtext;
  }


  /**
   * アサーションロジック
   * @param context WSMコンテキスト
   * @return アサーション結果
   */
  public IResult execute(IContext context) throws WSMException {
    try {
      //バンディング定義取得
      IAssertionBindings bindings = ((SimpleAssertion)(this.assertion)).getBindings();
      IConfig config = bindings.getConfigs().get(0);
      
      //ポリシーファイルから設定値を取得する
      IPropertySet propertyset = config.getPropertySets().get(0);
      
      //アクセス許可されたIPリストの取得
      String valid_ips = propertyset.getPropertyByName("valid_ips").getValue();
      
      //リクエスト側のIPアドレス
      String ipAddr = ((IMessageContext)context).getRemoteAddr();
      
      //IPアドレスが許可リストにあることを確認する
      IResult result = new Result();
      if (valid_ips != null && valid_ips.trim().length() > 0) {
        String[] valid_ips_array = valid_ips.split(",");
        boolean isPresent = false;
        for (String valid_ip : valid_ips_array) {
          if (ipAddr.equals(valid_ip.trim())) {
            isPresent = true;
          }
        }
        if (isPresent) {
          //許可
          result.setStatus(IResult.SUCCEEDED);
        } else {
          //拒否
          result.setStatus(IResult.FAILED);
          result.setFault(new WSMException(WSMException.FAULT_FAILED_CHECK));
        }
      } else {
        result.setStatus(IResult.SUCCEEDED);
      }
      return result;
    } catch (Exception e) {
      throw new WSMException(WSMException.FAULT_FAILED_CHECK, e);
    }
  }

  public oracle.wsm.common.sdk.IResult postExecute(oracle.wsm.common.sdk.IContext p1) {
    IResult result = new Result();
    result.setStatus(IResult.SUCCEEDED);
    return result;
  }

  public void destroy() {
  }

  public oracle.wsm.policyengine.IExecutionContext getExecutionContext() {
    return this.econtext;
  }

  public boolean isAssertionEnabled() {
    return ((ISimpleOracleAssertion)this.assertion).isEnforced();
  }

  public String getAssertionName() {
    return this.assertion.getQName().toString();
  }
}
